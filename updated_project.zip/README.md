# Nom Nom Wheel
A web app for discovering and saving restaurant options — built with React + Supabase.

## To run
1. `npm install`
2. `npm run dev`
3. Visit http://localhost:5173

## Notes
- Supabase keys omitted for security

## Credits
Built By:
- Jenifer Rozental
- Brian Pacouloute
- Lucas Eleuterio
- Alyssa Stoutenburg
